#pragma once
#include "Game/Player.h"

class Store {
public:
	static void open(Player& player);
};
