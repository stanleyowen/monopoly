#pragma once
#include "Game/Player.h"

class Event {
public:
	static void trigger(Player& player);
};
