#pragma once

class WelcomingScreen
{
public:
    void displayWelcomeScreen();
    void displayStartGame();
};