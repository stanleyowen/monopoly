#pragma once
#include "Player.h"

class MiniGame {
public:
	static void playHorseRace(Player& player);
};