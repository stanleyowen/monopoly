#pragma once

class WelcomingScreen
{
public:
    void clearScreen();
    void displayWelcomeScreen();
    void displayStartGame();
};