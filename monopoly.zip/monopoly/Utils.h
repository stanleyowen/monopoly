#pragma once

class Utils {
public:
	static void clearScreen();
};
