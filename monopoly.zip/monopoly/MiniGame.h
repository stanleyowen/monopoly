#pragma once
#include "Player.h"

class MiniGame {
public:
	static void play(Player& player);
};
