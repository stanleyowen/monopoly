#pragma once

class Dice {
public:
	static int roll();
};
