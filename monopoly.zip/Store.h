#pragma once
#include "Player.h"

class Store {
public:
	static void open(Player& player);
};
